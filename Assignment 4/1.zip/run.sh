python3 1.py $1

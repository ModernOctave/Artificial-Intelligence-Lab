The program can be run as follows:

python3 1.py <input file>

or using the run script:

./run.sh <input file>
